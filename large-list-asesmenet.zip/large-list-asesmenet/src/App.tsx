import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { Table, Pagination } from './components';
import { obfuscateSSNFromData } from './utils';
import data from './assets/users.json';
import 'bootstrap/dist/css/bootstrap.min.css';

// Even though this really shouldn't be outside the app
// It is just for the purpose of the exercise.
// Make sure to complete the utility function
// in order to obfuscate SSN numbers.
const staticData = obfuscateSSNFromData(data);

function App() {

  return (
    <Pagination items={staticData} limit={100}>
      <Container>
        <Row style={{ marginTop: '30px' }}>
          <Col>
            <Table></Table>
          </Col>
        </Row>
      </Container>
    </Pagination>

  );
}

export default App;
