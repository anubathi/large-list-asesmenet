import React from 'react';
import { Table } from 'react-bootstrap';

import { formatTableHeaders } from '../../utils';
import { TableRow } from './TableRow';
import { IUser } from '../../types';
import { PaginationContext, IPaginationContext } from '../Pagination/Pagination';



export const TableComponent = (props: any) => {


  const context = React.useContext<IPaginationContext>(PaginationContext);

  const [records, setRecords] = React.useState<IUser[]>([]);
  const [headers, setHeaders] = React.useState<string[]>([]);

  React.useEffect(() => {
    // Set the records here.
    setRecords(context.items);
  }, [setRecords, context]);

  React.useEffect(() => {
    const _headers = records.length > 0 ? Object.keys(records[0]) : [];
    // Make sure to complete the formatTableHeaders requirement.
    setHeaders(formatTableHeaders(_headers));
  }, [setHeaders, records])

  return (
    <Table hover bordered>
      <thead>
        <tr>
          {headers.map((header, i) => (
            <th key={i}>{header}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {records.map((record, i) => (<TableRow record={record} key={i}></TableRow>))}
      </tbody>
    </Table>
  );
};