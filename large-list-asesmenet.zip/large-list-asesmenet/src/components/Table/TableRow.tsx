import React from 'react';
import { IUser } from '../../types';
import ReactPaginate from 'react-paginate';

export interface TableRowProps {
  record: IUser;
};

export const TableRow = ({ record }: TableRowProps) => {
  // Here we can create class based component
  //we need to install react paginate library for pagination purpose
  constructor(props) {
        super(props);
        this.state = {
            offset: 0,
            data: [],
            perPage: 10,
            currentPage: 0
        };
        this.handlePageClick = this
            .handlePageClick
            .bind(this);
    }
  const values = Object.values(record);
  handlePageClick = (e) => {
    const selectedPage = e.selected;
    const offset = selectedPage * this.state.perPage;

    this.setState({
        currentPage: selectedPage,
        offset: offset
    }, () => {
        this.receivedData()
    });

  };
  receivedData = () => {
    return data;
  }
  return (
    <tr>
      {values.map((value, i) => (
        <td key={i}>{value}</td>
      ))}
                <ReactPaginate
                    previousLabel={"prev"}
                    nextLabel={"next"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={this.state.pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={5}
                    onPageChange={this.handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"}
                  />
    </tr>
  )
};