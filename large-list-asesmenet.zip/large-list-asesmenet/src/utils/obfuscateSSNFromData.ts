import { IUser } from "../types";

/**
 * Obfuscates the SSN column from each record within the data array.
 * This is intentionally left blank so you can fill it out.
 * 
 * @param {IUser[]} data The array of data elements you need to obfuscate.
 * 
 * @returns {IUser[]} The obfuscated array of data elements.
*/
export const obfuscateSSNFromData = (data: IUser[]): IUser[] => {

  return data;
}