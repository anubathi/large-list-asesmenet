import { useState, useEffect, RefObject } from 'react';

export interface ScrollState {
  x: number;
  y: number;
  scrolling: boolean;
  direction: string;
};

/**
 * Takes a reference HTMLElement and listens 
 * for scrolling within that element. Will return
 * the scrollWidth and scrollHeight. 
 * 
 * @param {RefObject<any>?} ref The referenced HTMLElement you want to listen to scroll for. Defaults
 * to window as the scroll listener if no reference is defined. 
 * 
 * @returns {ScrollState} returns the state of scrolling and the position of the scroll.
*/
const useScroll = (ref?: RefObject<any>) => {

  const [scroll, setScroll] = useState<ScrollState>({
    y: 0,
    x: 0,
    scrolling: false,
    direction: ""
  });

  useEffect(() => {
    let scrollingTimeout: any;
    if (ref?.current) {

      const cur = ref.current;

      const scrollHandler = () => {
        setScroll(prev => {
          return {
            y: cur.scrollTop || 0,
            x: cur.scrollLeft || 0,
            scrolling: true,
            direction: cur.scrollTop > prev.y ? 'down' : 'up'
          }
        });
        clearTimeout(scrollingTimeout);
        scrollingTimeout = setTimeout(() => handleScrollEnd(), 500);
      };
      const handleScrollEnd = () => {
        const newScroll = Object.assign({}, scroll, {
          scrolling: false,
          direction: ""
        });
        setScroll(newScroll);
      };

      cur.addEventListener('scroll', scrollHandler, {
        capture: false,
        passive: true
      });

      return () => {
        if (cur) {
          cur.removeEventListener('scroll', scrollHandler);
        }
      }
    } else {
      const windowScrollHandler = () => {
        setScroll(prev => {
          return {
            y: window.scrollY || 0,
            x: window.scrollX || 0,
            scrolling: true,
            direction: window.scrollY > prev.y ? 'down' : 'up'
          }
        });
        clearTimeout(scrollingTimeout);
        scrollingTimeout = setTimeout(() => windowScrollEnd(), 500);
      };
      const windowScrollEnd = () => {
        const newScroll = Object.assign({}, scroll, {
          scrolling: false,
          direction: ""
        });
        setScroll(newScroll);
      };

      window.addEventListener('scroll', windowScrollHandler, {
        capture: false,
        passive: true
      });

      return () => {
        window.removeEventListener('scroll', windowScrollHandler);
      }
    }

  }, [ref, scroll]);

  return scroll;
};

export default useScroll;