
/**
 * Formats all the table headers to read as a title.
 * This is intentionally left blank. You will need to 
 * format the table headers yourself.
 * 
 * @param {string[]} headers The array of header elements you need to format.
 * 
 * @returns {string[]} The formatted headers as an array of strings.
*/
export const formatTableHeaders = (headers: string[]): string[] => {
  return headers;
};