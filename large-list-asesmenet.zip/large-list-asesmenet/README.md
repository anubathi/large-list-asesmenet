# Large List Generation

#### Time: 40 minutes

#### Data file used: [users.json](./src/assets/users.json)

## Requirements

Complete as much of the requirements as you can within 40 minutes.

### Table generation

1. In the [Table](./src/components/Table/Table.tsx) component generate a [TableRow](./src/components/Table/TableRow.tsx) component for every record in the context.items value.
2. The list needs to render the items in an efficient way, and cannot render all the items at once.
3. The max number of rendered [TableRow](./src/components/Table/TableRow.tsx) components can only be 100 at a time.
4. Indicate when you are loading more items.
5. Complete the [Pagination](./src/components/Pagination/Pagination.tsx) context provider component to paginate the data.

### Styling

1. All `<th>` html elements, must be formatted in a title format. For example, if I have a header value of `first_name` the header inner text should render `First Name`. [Formatting function can be found here](./src/utils/formatTableHeaders.ts)
2. There needs to be a loading indicator to let the user know that there are more [TableRow](./src/components/Table/TableRow.tsx) components being rendered.
3. The all the characters SSN value field need to be masked with `*` except for the last 4 digits. [Obfuscation function can be found here](./src/utils/obfuscateSSNFromData.ts)
